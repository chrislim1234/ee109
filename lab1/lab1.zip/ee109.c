/********************************************
*
*  Name:
*  Section:
*  Assignment:
*
********************************************/

#include <avr/io.h>

int main(void)
{
    // Your program goes here

    while(1) {
    }

    return 0;   /* never reached */
}
